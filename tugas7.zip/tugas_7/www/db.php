<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id8941596_admin","aturbancak","id8941596_tugas") or die ("could not connect database");
?>
